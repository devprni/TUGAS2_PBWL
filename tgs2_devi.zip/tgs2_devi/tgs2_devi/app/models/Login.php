<?php

namespace App\Models;

use App\Core\Model;

class Login extends Model
{

      public function proses_login($username,$password)
      {
        $row = $this->db->prepare('SELECT * FROM tb_users  WHERE user_email=? AND user_password=?');
        $row->execute(array($username,$password));
        $count = $row->rowCount();
        if($count > 0)
        {
            return $hasil = $row->fetch();
        }else{
            return false;
        }
      }

      public function proses_daftar($username,$password,$user_nama,$user_alamat,$user_hp,$user_pos){


        //SQL
        $sql = "INSERT INTO tb_users (user_email,user_password,user_nama,user_alamat,user_hp,user_pos,user_role,user_aktif) VALUES
        (:username,:password,:user_nama,:user_alamat,:user_hp,:user_pos,1,1)";
        //bindParam
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":username", $username);
        $stmt->bindParam(":password", $password);
        $stmt->bindParam(":user_nama", $user_nama);
        $stmt->bindParam(":user_alamat", $user_alamat);
        $stmt->bindParam(":user_hp", $user_hp);
        $stmt->bindParam(":user_pos", $user_pos);
        $stmt->execute();
        return $stmt;
      }

}
