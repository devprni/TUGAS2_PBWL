    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">

<div class="card border-light m-3 p-5">
  <div class="card-body text-success">
    <h5 class="card-title">Selamat datang,</h5>
    <p class="card-text">Silahkan login terlebih dahulu untuk mengakses aplikasi.</p>
  </div>
</div>