<?php

namespace App\Controllers;

use App\Core\Controller;

class Golongan extends Controller
{

      public function __construct()
      {
            $this->model = new \App\Models\Golongan();
      }

      public function index()
      {

        $data = [
              'status' => ' ',
            ];
            $data['rows'] = $this->model->all();
            $this->pelanggan('golongan/index', $data);
      }
      

      public function input()
      {
        $data = [
              'status' => ' ',
            ];
       $this->pelanggan('golongan/tambah',$data);     
    if(isset($_POST['tambah'])){
        $gol_kode = $_POST['gol_kode'];
        $gol_nama = $_POST['gol_nama'];

        $result = $this->model->proses_tambah($gol_kode,$gol_nama);
        if($result)
        {
            $data = [
              'status' => 'berhasil!',
            ];
            $this->pelanggan('golongan/tambah',$data);
            
        }else{
            $data = ['status' => 'gagal!'];
            $this->pelanggan('golongan/tambah',$data);

        }            
}      
      }

      public function edit($id)
      {
      }

      public function update($id)
      {
      }

      public function detail($id)
      {
      }

      public function delete($gol_id)
      {
               if (isset($_GET['gol_id'])) {
       // Inisialisasi
       $gol_id = $_GET['gol_id'];
        $data = [
              'status' => ' ',
            ];

        if($this->model->hapus($gol_id)){
        $data = [
              'status' => ' ',
            ];
            $data['rows'] = $this->model->all();
            $this->pelanggan('golongan/index', $data);

            }else{
                die('something went wrong');
            }
      }
}
}
