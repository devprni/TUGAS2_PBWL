<body>
    <div class="container">
      <div class="row justify-content-center mt-5">
        <div class="col-md-4">
          <div class="card">
            <div class="card-header bg-transparent mb-0"><h5 class="text-center"> <span class="font-weight-bold text-primary">Daftar</span></h5></div>
            <div class="card-body">
              <form action="<?php echo URL; ?>/login/p_daftar" method="POST">
                <div class="form-group">
                    <label for="exampleFormControlInput1" class="form-label">Email :</label>                  
                  <input type="text" name="username" class="form-control" placeholder="Username">
                </div>
                <div class="form-group">
                                      <label for="exampleFormControlInput1" class="form-label">Password :</label>
                  <input type="password" name="password" class="form-control" placeholder="Password">
                </div>
                <div class="form-group">
                                      <label for="exampleFormControlInput1" class="form-label">Username :</label>
                  <input type="text" name="user_nama" class="form-control" placeholder="Nama">
                </div>  
                <div class="form-group">
                                      <label for="exampleFormControlInput1" class="form-label">Alamat :</label>
                  <input type="text" name="user_alamat" class="form-control" placeholder="alamat">
                </div>
                <div class="form-group">
                                      <label for="exampleFormControlInput1" class="form-label">HP :</label>
                  <input type="text" name="user_hp" class="form-control" placeholder="hp">
                </div>
                <div class="form-group">
                                      <label for="exampleFormControlInput1" class="form-label">Pos :</label>
                  <input type="text" name="user_pos" class="form-control" placeholder="pos">
                </div>                                                              
                <div class="form-group m-3">
                  <input type="submit" name="daftar" value="Daftar" class="btn btn-primary btn-block">
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
  <footer align="center">copyright &copy;</footer>