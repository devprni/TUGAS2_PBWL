<body>
      <h4><?php echo $data['status'];?></h4>
    <div class="container">
      <div class="row justify-content-center mt-5">
        <div class="col-md-4">
          <div class="card">
            <div class="card-header bg-transparent mb-0"><h5 class="text-center">Tambah Data Pelanggan </h5></div>
            <div class="card-body">
              <form action="<?php echo URL; ?>/pelanggan/input/" method="POST">
                <div class="form-group">
                    <label for="exampleFormControlInput1" class="form-label">Nama Pelanggan :</label>
                  <input type="text" name="pel_nama" class="form-control" >
                </div>
                <div class="form-group">
                                        <label for="exampleFormControlInput1" class="form-label">Golongan :</label>
                  <input type="text" name="pel_id_gol" class="form-control">
                </div>
                <div class="form-group">
                                        <label for="exampleFormControlInput1" class="form-label">Alamat :</label>
                  <input type="text" name="pel_alamat" class="form-control">
                </div>
                <div class="form-group">
                                        <label for="exampleFormControlInput1" class="form-label">HP :</label>
                  <input type="text" name="pel_hp" class="form-control">
                </div>
                <div class="form-group">
                                        <label for="exampleFormControlInput1" class="form-label">KTP :</label>
                  <input type="text" name="pel_ktp" class="form-control">
                </div>                
                <div class="form-group">
                                        <label for="exampleFormControlInput1" class="form-label">Seri :</label>
                  <input type="text" name="pel_seri" class="form-control">
                </div>
                <div class="form-group">
                                        <label for="exampleFormControlInput1" class="form-label">Meteran :</label>
                  <input type="text" name="pel_meteran" class="form-control">
                </div>
                <div class="form-group m-2">
                  <input type="submit" name="tambah" value="Tambah" class="btn btn-primary btn-block">
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>