<?php

namespace App\Controllers;

use App\Core\Controller;

class Login extends Controller
{
      public function __construct()
      {
            $this->model1 = new \App\Models\Login();
            $this->model = new \App\Models\Pelanggan();
      }
	public function index()
	{
         $data = [
              'status' => ' ',
            ];
	$this->home('login/index',$data);

}
public function p_login(){

    if(isset($_POST['login'])){
        $username = $_POST['username'];
        $password = $_POST['password'];
        
        $result = $this->model1->proses_login($username,$password);
        if($result)
        {
                    $data = [
              'status' => ' berhasil login!',
            ];
                        $data['rows'] = $this->model->all();
        	$this->pelanggan('pelanggan/index', $data);
            
        }else{
                    $data = [
              'status' => ' password salah!',
            ];            
        $this->home('login/index',$data);
        }
    }
}
public function daftar(){
    $this->home('login/daftar');
}

public function p_daftar(){
        $data = [
              'status' => ' ',
            ];
    if(isset($_POST['daftar'])){
        $username = $_POST['username'];
        $password = $_POST['password'];
        $user_alamat = $_POST['user_alamat'];
        $user_nama = $_POST['user_nama'];
        $user_hp = $_POST['user_hp'];
        $user_pos = $_POST['user_pos'];

        $result = $this->model1->proses_daftar($username,$password,$user_nama,$user_alamat,$user_hp,$user_pos);
        if($result)
        {
            $data = [
              'status' => 'berhasil daftar!',
            ];
            $this->home('login/index',$data);
            
        }else{
            $data = ['status' => 'gagal!'];
            $this->home('login/index',$data);

        }            
}      
      }
}
